from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    
    def __init__(self, user, pwd):
        self.client = MongoClient(f'mongodb://{user}:{pwd}@nv-desktop-services.apporto.com:32497')
        self.database = self.client['AAC']
        print('Hello, Animal Shelter')

    # Create method for C in CRUD
    def create(self, data):
        print("in create method...")
        if data is not None:
            try:
                self.database.animals.insert_one(data)
                return True
            except Exception as e:
                print(f"Error while inserting: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method for R in CRUD
    def read(self, searchTerm):
        print("in read method...")
        if searchTerm is not None:
            result = list(self.database.animals.find(searchTerm))
            return result
        else:
            raise Exception("Nothing to find, because search parameter is empty")

    # Update method for U in CRUD
    def update(self, searchTerm, infoToChange):
        print("in update method...")
        if searchTerm and infoToChange is not None:
            result = self.database.animals.update_many(searchTerm, {"$set": infoToChange})
            print(f"Number of updated entries: {result.matched_count}")
            return result.matched_count > 0
        else:
            raise Exception("Search term or info to change is empty")
    
    # Delete method for D in CRUD
    def delete(self, searchTerm):
        print("in delete method...")
        if searchTerm is not None:
            result = self.database.animals.delete_many(searchTerm)
            print(f"Number of deleted entries: {result.deleted_count}")
            return result.deleted_count > 0
        else:
            raise Exception("Search term is empty")

     
